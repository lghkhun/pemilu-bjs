<?php
defined('BASEPATH') or die("No Access Allowed");
?>
<div class="text-center" style="padding-top:20px;padding-bottom:40px;">
   <div style="padding-bottom:10px">
      <img src="./assets/img/unisa.png" class="img-thanks" alt="Slideshow 1" >
   </div>
   <h2>Terima kasih atas partisipasinya</h2>
   <p>Suara yang diberikan menentukan masa depan kerukunan Perum Bangunjiwo Sejahtera</p>
   <a href="./" class="button alert large">Kembali</a>
</div>
